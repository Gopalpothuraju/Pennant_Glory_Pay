package com.pennant.glorypay.commands;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.pennant.glorypay.beans.Glory_Pay_Users;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

@MultipartConfig
public class SignUpCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {
			response.setContentType("text/html;charset=UTF-8");
			String mobile = request.getParameter("mobile");
			String aadhaar_Card = request.getParameter("aadhaar_Card");
			String pan_Card = request.getParameter("pan_Card");
			String mail_Id = request.getParameter("mail_Id");
			String type_Of_User = request.getParameter("type_Of_User");
			String doB1 = request.getParameter("doB");

			double ciBil_Score = 0.0;
			if (type_Of_User.equalsIgnoreCase("Employee")) {
				ciBil_Score = 100.0;
			} else {
				ciBil_Score = 10.0;
			}
			String password = request.getParameter("password");

			Part profile_Image = request.getPart("profile_Image");
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date(System.currentTimeMillis());
			String doj = formatter.format(date);
			Glory_Pay_Users users = new Glory_Pay_Users(mobile, aadhaar_Card, pan_Card, doj, mail_Id, type_Of_User,
					doB1, profile_Image, ciBil_Score, password);
			GloryPayDao user = new GloryPayDaoImpl();
			if (user.insertUser(users)) {
				response.sendRedirect("register.jsp");
			} else {
				response.sendRedirect("login.jsp");
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ServletException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
}
