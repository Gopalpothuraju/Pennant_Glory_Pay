package com.pennant.glorypay.commands;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.beans.Glory_Pay_Users;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class LoginCommand implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
	doPost(request, response);
		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();

		String uname = request.getParameter("ename");
		String password = request.getParameter("pwd");

		Glory_Pay_Users users = new Glory_Pay_Users();
		users.setMail_Id(uname);
		users.setPassword(password);
		GloryPayDao dao = new GloryPayDaoImpl();
		try {
			Glory_Pay_Users current_User = dao.checkValidUser(users);
			if (current_User != null) {
				session.setAttribute("userName", current_User.getMail_Id());
				session.setAttribute("type", current_User.getType_Of_User());
				session.setAttribute("mobileNumber", current_User.getMobile_Number());
				session.setAttribute("cibilScore", current_User.getCiBil_Score());
				response.sendRedirect("HomePage.jsp?usr=" + uname);

			} else {
				response.sendRedirect("login.jsp");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}


