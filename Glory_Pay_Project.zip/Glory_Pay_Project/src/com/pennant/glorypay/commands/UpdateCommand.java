package com.pennant.glorypay.commands;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.beans.Glory_Pay_Users;
import com.pennant.glorypay.commands.Command;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class UpdateCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session=request.getSession();
		String mobile=(String)session.getAttribute("mobileNumber");
		Glory_Pay_Users users=new Glory_Pay_Users();
	 users.setMobile_Number(mobile);
	 GloryPayDao dao = new GloryPayDaoImpl();
	 Glory_Pay_Users rs = (Glory_Pay_Users) dao.updateUsers(users);
	 if(dao.updateUsers(users)!=null){
		 request.setAttribute("rows", rs);
		 RequestDispatcher dispatcher = request.getRequestDispatcher("/update.jsp");
		 try {
				dispatcher.forward(request, response);
			} catch (ServletException e) {
							e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}
	}

}
