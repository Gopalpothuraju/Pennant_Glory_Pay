package com.pennant.glorypay.commands;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Command {
public abstract void doGet(HttpServletRequest request,HttpServletResponse response);
public abstract void doPost(HttpServletRequest request,HttpServletResponse response);
}
