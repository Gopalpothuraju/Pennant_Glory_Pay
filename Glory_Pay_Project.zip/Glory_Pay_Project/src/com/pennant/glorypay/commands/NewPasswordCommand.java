package com.pennant.glorypay.commands;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class NewPasswordCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		response.setContentType("text/html;charset=UTF-8");
		try {
			PrintWriter out = response.getWriter();
			HttpSession session=request.getSession();
			String email = (String)session.getAttribute("forget");
			String pwd = request.getParameter("pwd");
			String cnpwd = request.getParameter("cnpwd");
			GloryPayDao dao=new GloryPayDaoImpl();
			if(pwd.equals(cnpwd)){
				int i = dao.updatePassword(pwd,email);
				if(i>0){
					out.println("<b style='color:green'>Your Password is successfully changed.</b>");
					out.print("<a href='index.jsp'>click here</a>");
				}
		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
