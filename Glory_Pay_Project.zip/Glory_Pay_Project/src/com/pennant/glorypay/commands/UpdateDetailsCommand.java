package com.pennant.glorypay.commands;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.glorypay.beans.Glory_Pay_Users;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class UpdateDetailsCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String mobileNumber=request.getParameter("mobile");
		String aadhaar = request.getParameter("aadhaar");
		String panNumber = request.getParameter("pan");
		String doj = request.getParameter("doj");
		String mailId = request.getParameter("mailId");
		String typeOfUser = request.getParameter("type_Of_User");
		String dob = request.getParameter("dob");
		String password = request.getParameter("password");
		Glory_Pay_Users user=new Glory_Pay_Users(mobileNumber,aadhaar,panNumber,doj,mailId,typeOfUser,dob,password);
		GloryPayDao dao=new GloryPayDaoImpl();
		dao.updateUserDetails(user);
		try {
			response.sendRedirect("HomePage.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
