package com.pennant.glorypay.commands;

import java.io.IOException;
import java.io.PrintWriter;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.pennant.glorypay.beans.Glory_Pay_Docs_Verify;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;
import com.pennant.glorypay.mails.GloryPayMail;

public class LoanProceedCommand implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
doPost(request, response);		
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {
			HttpSession session=request.getSession();
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
		GloryPayMail mail=new GloryPayMail();
		String loanTpye = request.getParameter("loanType");
		session.setAttribute("loanType", loanTpye);
		String typeOfUser = (String)session.getAttribute("type");
		if(typeOfUser.equalsIgnoreCase("Employee")){
		String empId = request.getParameter("id");
		Part offerLetter = request.getPart("offerletter");
		Part paySlip = request.getPart("payslip");
		Part bankstatement = request.getPart("bankstatement");
		
		
		String mobileNumber = (String)session.getAttribute("mobileNumber");
		Glory_Pay_Docs_Verify user=new Glory_Pay_Docs_Verify(mobileNumber, empId, offerLetter, paySlip, bankstatement);
		GloryPayDao dao=new GloryPayDaoImpl();
		if(!dao.insertDocuments(user)){
			mail.setMailServerProperties();
			mail.createEmailMessage(request, response);
			mail.sendEmail();
			response.sendRedirect("loanapprove.jsp");
		}else{
			out.println("Sorry..Please check your documents...!!!");
			out.print("<a href='HomePage.jsp'>click here</a>");
		}
		}else{
			mail.setMailServerProperties();
			mail.createEmailMessage(request, response);
			mail.sendEmail();
			response.sendRedirect("loanapprove.jsp");
		}
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
