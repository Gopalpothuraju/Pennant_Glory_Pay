package com.pennant.glorypay.commands;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.glorypay.mails.GloryPayMail;

public class PaymentCommand implements Command{

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		GloryPayMail mail=new GloryPayMail();
		try {
			mail.setMailServerProperties();
			mail.createEmailMessage(request, response);
			mail.sendEmail();
			response.sendRedirect("payment.jsp");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
