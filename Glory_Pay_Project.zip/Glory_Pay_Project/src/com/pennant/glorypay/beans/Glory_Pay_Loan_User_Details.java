package com.pennant.glorypay.beans;

public class Glory_Pay_Loan_User_Details {
	private String mobile_Number;
	private String typeOfLoan;
	private String dateOfLOAN;
	private double loanAmount;
	private String result;
	private double paybleAmount;
	private double remainingAmount;
	private double tenure;
	
	
	 public Glory_Pay_Loan_User_Details() {
		// TODO Auto-generated constructor stub
	}
	public Glory_Pay_Loan_User_Details(String mobile_Number, String typeOfLoan, String dateOfLOAN, double loanAmount,
			String result, double paybleAmount, double remainingAmount, double tenure) {
		super();
		this.mobile_Number = mobile_Number;
		this.typeOfLoan = typeOfLoan;
		this.dateOfLOAN = dateOfLOAN;
		this.loanAmount = loanAmount;
		this.result = result;
		this.paybleAmount = paybleAmount;
		this.remainingAmount = remainingAmount;
		this.tenure = tenure;
	}
	public Glory_Pay_Loan_User_Details(String mobile_Number) {
		super();
		this.mobile_Number = mobile_Number;
	}
	public String getMobile_Number() {
		return mobile_Number;
	}
	public void setMobile_Number(String mobile_Number) {
		this.mobile_Number = mobile_Number;
	}
	public String getTypeOfLoan() {
		return typeOfLoan;
	}
	public void setTypeOfLoan(String typeOfLoan) {
		this.typeOfLoan = typeOfLoan;
	}
	public String getDateOfLOAN() {
		return dateOfLOAN;
	}
	public void setDateOfLOAN(String dateOfLOAN) {
		this.dateOfLOAN = dateOfLOAN;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public double getPaybleAmount() {
		return paybleAmount;
	}
	public void setPaybleAmount(double paybleAmount) {
		this.paybleAmount = paybleAmount;
	}
	public double getRemainingAmount() {
		return remainingAmount;
	}
	public void setRemainingAmount(double remainingAmount) {
		this.remainingAmount = remainingAmount;
	}
	public double getTenure() {
		return tenure;
	}
	public void setTenure(double tenure) {
		this.tenure = tenure;
	}
	@Override
	public String toString() {
		return "Glory_Pay_Loan_User_Details [mobile_Number=" + mobile_Number + ", typeOfLoan=" + typeOfLoan
				+ ", dateOfLOAN=" + dateOfLOAN + ", loanAmount=" + loanAmount + ", result=" + result + ", paybleAmount="
				+ paybleAmount + ", remainingAmount=" + remainingAmount + ", tenure=" + tenure + "]";
	}
	
}