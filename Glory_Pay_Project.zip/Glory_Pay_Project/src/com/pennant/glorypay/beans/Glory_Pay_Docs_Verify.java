package com.pennant.glorypay.beans;

import javax.servlet.http.Part;

public class Glory_Pay_Docs_Verify {

	private String mobile_Number;
	private String employee_Id;
	private Part offer_Letter;
	private Part pay_Slip;
	private Part bank_Statement;
	
	//Constructor
	public Glory_Pay_Docs_Verify() {
		super();
	}

	//Constructor
	
	//getters and setters 
	
	public String getMobile_Number() {
		return mobile_Number;
	}


	public Glory_Pay_Docs_Verify(String mobile_Number, String employee_Id, Part offer_Letter, Part pay_Slip,
			Part bank_Statement) {
		super();
		this.mobile_Number = mobile_Number;
		this.employee_Id = employee_Id;
		this.offer_Letter = offer_Letter;
		this.pay_Slip = pay_Slip;
		this.bank_Statement = bank_Statement;
	}

	public void setMobile_Number(String mobile_Number) {
		this.mobile_Number = mobile_Number;
	}


	public String getEmployee_Id() {
		return employee_Id;
	}


	public void setEmployee_Id(String employee_Id) {
		this.employee_Id = employee_Id;
	}


	
	public Part getOffer_Letter() {
		return offer_Letter;
	}

	public void setOffer_Letter(Part offer_Letter) {
		this.offer_Letter = offer_Letter;
	}

	public Part getPay_Slip() {
		return pay_Slip;
	}

	public void setPay_Slip(Part pay_Slip) {
		this.pay_Slip = pay_Slip;
	}

	public Part getBank_Statement() {
		return bank_Statement;
	}

	public void setBank_Statement(Part bank_Statement) {
		this.bank_Statement = bank_Statement;
	}

	//toString
	@Override
	public String toString() {
		return "Glory_Pay_Docs_Verify [Mobile_Number=" + mobile_Number + ", employee_Id=" + employee_Id
				+ ", offer_Letter=" + offer_Letter + ", pay_Slip=" + pay_Slip + ", bank_Statement=" + bank_Statement
				+ "]";
	}
	
	
	
	
}
